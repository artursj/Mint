jQuery(window).on('load', function () {
	window.iPhorm.preload([
		'input-active-bg-rep.png',
		'file-upload-progress-area.png',
		'file-progress-bar-bg.png',
		'input-active-bg-rep.png',
		'file-close.png',
		'button-active-bg-rep.png'
	], iphormL10n.plugin_url + '/themes/light/images/');
});
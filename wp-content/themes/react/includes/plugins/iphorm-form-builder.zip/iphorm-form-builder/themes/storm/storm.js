jQuery(document).ready(function ($) {
	window.iPhorm.preload([
       'file-progress-bg.png',
       'file-progress-bar-bg.png',
       'file-close.png',
       'file-upload-tick.png',
       'button-active-bg-rep.png',
       'captcha-refresh-icon.png',
       'loading.gif'
    ], iphormL10n.plugin_url + '/themes/storm/images/');
});
jQuery(window).on('load', function () {
	window.iPhorm.preload([
		'input-active-bg-rep.png',
		'file-upload-progress-area.png',
		'file-progress-bg.png',
		'file-progress-bar-bg.png',
		'input-active-bg-rep.png',
		'file-close.png',
		'file-upload-tick.png',
		'button-active-bg-rep.png',
		'captcha-refresh-icon.png',
		'loading.gif'
	], iphormL10n.plugin_url + '/themes/dark/images/');
});
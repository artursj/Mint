<?php if (!defined('IPHORM_VERSION')) exit; ?><h4>Do not show in the email</h4>
<p>When checked the element's value will not be shown in the default notification email.</p>
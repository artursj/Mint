<?php if (!defined('IPHORM_VERSION')) exit; ?><div class="iphorm-help-left">
    <ul>
        <li><a href="#faq-licence">License</a></li>
        <li><a href="#faq-styling">Styling &amp; layout</a></li>
        <li><a href="#faq-website">On your website</a></li>
        <li><a href="#faq-email">Email</a></li>
        <li><a href="#faq-entries">Entries</a></li>
        <li><a href="#faq-translating">Translating</a></li>
        <li><a href="#faq-theming">Themes</a></li>
        <li><a href="#faq-troubleshooting">Troubleshooting</a></li>
    </ul>
</div>
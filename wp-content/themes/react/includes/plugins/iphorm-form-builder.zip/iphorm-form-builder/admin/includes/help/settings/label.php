<?php if (!defined('IPHORM_VERSION')) exit; ?><h4>Label</h4>
<p>The label is the text that appears usually above the form element.</p>
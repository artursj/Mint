<?php if (!defined('IPHORM_VERSION')) exit; ?><h4>Options layout</h4>
<p>Choose whether to have your options inline, or each option on a new line.</p>
<?php
if (!defined('IPHORM_VERSION')) exit;
include IPHORM_ADMIN_INCLUDES_DIR . '/help/_nav-elements.php';
?>
<div class="iphorm-help-right">
<h2>HTML Element</h2>
<p>The HTML element can be used to add any amount of HTML to your form.</p>
<h3><span>Configuration options</span></h3>
<h4>HTML</h4>
<p>Enter your HTML into the box.</p>
<?php include IPHORM_ADMIN_INCLUDES_DIR . '/help/settings/conditional-logic.php'; ?>
</div>
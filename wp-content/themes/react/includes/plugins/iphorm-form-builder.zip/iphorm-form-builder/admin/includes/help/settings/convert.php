<?php if (!defined('IPHORM_VERSION')) exit; ?><h4>Convert element</h4>
<p>You can convert your element between Dropdown Menu, Multiple Choice and Checkboxes. Select
the element type you want to change to and click OK at the warning message to do this.
All your options and mostly all of your settings will be copied over, the only settings you may lose
are those that are not shared between the elements.</p>
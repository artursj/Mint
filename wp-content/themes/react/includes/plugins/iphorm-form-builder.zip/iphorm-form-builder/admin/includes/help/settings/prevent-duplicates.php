<?php if (!defined('IPHORM_VERSION')) exit; ?><h4>Prevent duplicates</h4>
<p>Prevents the form being submitted if a form has previously been submitted with the same value for
this element.</p>
<h4>Error message if duplicate found</h4>
<p>Translate or override the error message shown under a field when
a duplicate value is found. The default is "This value is a
duplicate of a previously submitted form".</p>
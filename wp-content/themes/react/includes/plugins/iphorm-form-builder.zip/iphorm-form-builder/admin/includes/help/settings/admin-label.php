<?php if (!defined('IPHORM_VERSION')) exit; ?><h4>Admin label</h4>
<p>The admin will be shown throughout the form builder when referring to this element and also it will be
the label for the element in the notification email. The text will not be displayed to the form user.</p>
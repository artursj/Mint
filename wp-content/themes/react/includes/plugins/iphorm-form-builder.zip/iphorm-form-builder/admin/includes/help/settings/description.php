<?php if (!defined('IPHORM_VERSION')) exit; ?><h4>Description</h4>
<p>The description appears underneath the form element and is useful for giving instructions to the user
to assist them filling out the form.</p>
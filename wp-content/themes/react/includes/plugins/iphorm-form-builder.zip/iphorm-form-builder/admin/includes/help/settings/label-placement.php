<?php if (!defined('IPHORM_VERSION')) exit; ?><h4>Label placement</h4>
<p>Choose whether you want the labels above, left or inside the inputs. If you choose left, you
will also be able to specify the width of the label to help control your form layout. The
default value of Inherit means that the settings are inherited from the global form settings
that you can configure at <span class="ifb-bold">Settings &rarr; Style &rarr; Labels</span>.</p>
<?php if (!defined('IPHORM_VERSION')) exit; ?><h4>Tooltip text</h4>
<p>The text specified here will be displayed as a tooltip when the user hovers over the form element,
if tooltips are enabled. To disable tooltips, go to <span class="ifb-bold">Form Builder &rarr; Settings &rarr; Style &rarr; Tooltips</span>
and uncheck <span class="ifb-bold">Enable tooltips</span>.</p>
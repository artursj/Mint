<?php if (!defined('IPHORM_VERSION')) exit; ?><h4>Save value to the database</h4>
<p>If checked the submitted form value for the element will be saved in the entries database.
Uncheck if you do not want the value for this element to appear when viewing submitted form entries.</p>
<?php if (!defined('IPHORM_VERSION')) exit; ?><h4>Enable conditional logic</h4>
<p>Enables you to create rules to show or hide this field depending on the values of other fields.
Once you tick this box you will be able to set rules to control the logic.</p>

<h4>Logic rules</h4>
<p>Here you can add rules to determine which other fields need to have which value in order to show
or hide this field.</p>
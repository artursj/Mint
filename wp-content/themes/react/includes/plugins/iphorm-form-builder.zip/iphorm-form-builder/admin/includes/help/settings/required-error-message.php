<?php if (!defined('IPHORM_VERSION')) exit; ?><h4>Error message if required</h4>
<p>The text specified here will be displayed as the error message if the element is required and was left blank.</p>
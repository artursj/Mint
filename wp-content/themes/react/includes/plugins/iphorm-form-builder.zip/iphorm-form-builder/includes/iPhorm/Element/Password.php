<?php

/**
 * iPhorm_Element_Password
 *
 * Password element
 *
 * @package iPhorm
 * @subpackage Element
 * @copyright Copyright (c) 2009-2011 ThemeCatcher (http://www.themecatcher.net)
 */
class iPhorm_Element_Password extends iPhorm_Element
{
}
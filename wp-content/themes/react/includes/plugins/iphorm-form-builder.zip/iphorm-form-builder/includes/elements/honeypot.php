<?php if (!defined('IPHORM_VERSION')) exit; ?><div class="iphorm-hidden">
    <label><?php esc_html_e('This field should be left blank', 'iphorm'); ?><input type="text" name="<?php echo esc_attr($name); ?>" /></label>
</div>
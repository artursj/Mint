Please visit our website if you are interested in translating our plugin, see the links below.

Our translations are now managed at our GlotPress install: http://translate.themecatcher.net/

Translating guide (if not using GlotPress): http://support.themecatcher.net/quform-wordpress/guides/translating/translating-quform

If you've made an improvement to an existing translation, please consider sending both the .mo and .po files to info@themecatcher.net, so we can include your improvements in the next version of the plugin.

Warning: If you change a translation file included with the plugin it will be overwritten when the plugin is upgraded. If you've added your own translation files, they will be saved during plugin updates.
